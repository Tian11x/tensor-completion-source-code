function [IDX,dictionary]=tensor_block_sample(I,J,K,ID,JD,KD)

IDX=zeros(I,J,K); 
LengthI=length(ID);
LengthJ=length(JD);
LengthK=length(KD);

i=unidrnd(LengthI-1); 
j=unidrnd(LengthJ-1);  
k=unidrnd(LengthK-1);  

row_sta=ID(i)+1;  % 
row_end=ID(i+1);  % 
col_sta=JD(j)+1;  % 
col_end=JD(j+1);  % 
dep_sta=KD(k)+1;  % 
dep_end=KD(k+1);  % 

IDX(row_sta:row_end,col_sta:col_end,dep_sta:dep_end)=1;  %
%
IDX(row_sta:row_end,:,dep_sta:dep_end)=1;
IDX(row_sta:row_end,col_sta:col_end,:)=1;
IDX(:,col_sta:col_end,dep_sta:dep_end)=1;
dictionary=zeros(3,2);
dictionary(1,1)=row_sta;
dictionary(1,2)=row_end;
dictionary(2,1)=col_sta;
dictionary(2,2)=col_end;
dictionary(3,1)=dep_sta;
dictionary(3,2)=dep_end;
