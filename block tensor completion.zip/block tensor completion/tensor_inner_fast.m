function [T]=tensor_inner_fast(A,B,C)
[~,R]=size(A);%
lambda=ones(1,R);%
T=ktensor(lambda',A,B,C);
T=double(T);