function [X_recover,Curve_loss]=tensor_block_completion(X,IDX,dictionary,max_iter,max_iter_sub,R)

iter=1;       %
converge=0;   %
threshold=10; %
lambda=0.005; %
error_old=0;
Curve_loss=zeros(2,max_iter); %
[I,J,K]=size(X);         %
X_sample=X.*IDX;        
row_sta=dictionary(1,1);
row_end=dictionary(1,2);
col_sta=dictionary(2,1); 
col_end=dictionary(2,2); 
dep_sta=dictionary(3,1); 
dep_end=dictionary(3,2); 
Core=X_sample(row_sta:row_end,col_sta:col_end,dep_sta:dep_end);
Row=X_sample(:,col_sta:col_end,dep_sta:dep_end); 
Col=X_sample(row_sta:row_end,:,dep_sta:dep_end); 
Dep=X_sample(row_sta:row_end,col_sta:col_end,:); 
[~,n2,n3]=size(Core); 

A=rand(I,R); B=rand(n2,R); C=rand(n3,R);
while ~converge
    [Ar,Br,Cr]=tensor_block_A( Row,ones(size(Row)),R,lambda,threshold,max_iter_sub,A,B,C ); 
    A=Ar(row_sta:row_end,:);      B=rand(J,R);      C=Cr;
    [Ac,Bc,Cc]=tensor_block_B( Col,ones(size(Col)),R,lambda,threshold,max_iter_sub,A,B,C ); 
    A=Ac;      B=Bc(col_sta:col_end,:);      C=rand(K,R);
    [Ad,Bd,Cd]=tensor_block_C( Dep,ones(size(Dep)),R,lambda,threshold,max_iter_sub,A,B,C );
    A=rand(I,R);      B=Bd;      C=Cd(dep_sta:dep_end,:);
    
    
    X_recover=tensor_inner_fast(Ar,Bc,Cd);   
    [train_error,test_error]=tensor_recover_error(X,X_recover,IDX); %
    disp(['the train error of ' num2str(iter) '-th iteration is : ' num2str(train_error)]);
    res_error=abs(error_old-train_error);
    
    if max_iter<iter || res_error<10^-11
        converge=1;
    end
    error_old=train_error;
    
    Curve_loss(1,iter)=train_error;
    Curve_loss(2,iter)=test_error;
    iter=iter+1;
end
