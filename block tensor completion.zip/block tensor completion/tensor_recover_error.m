function [train_error,test_error]=tensor_recover_error(X,Xhat,IDX)

UIDX=ones(size(X))-IDX;
train_error=sqrt( sum(sum(sum( (X-Xhat).^2.*IDX ))) / sum(sum(sum( (X).^2.*IDX ))) );
test_error=sqrt( sum(sum(sum( (X-Xhat).^2.*UIDX ))) / sum(sum(sum( (X).^2.*UIDX ))) );