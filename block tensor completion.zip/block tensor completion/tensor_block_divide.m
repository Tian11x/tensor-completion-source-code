function [Loc_row,Loc_col,Loc_fib]=tensor_block_divide(I,J,K,d)

t1=0;   t2=0;    t3=0;   %
num1=1; num2=1;  num3=1; %
Loc_row=[]; Loc_col=[]; Loc_fib=[];%
flag1=0;flag2=0; flag3=0;%

%--------------------------------------------------------------%
%
while(t1<I)
    Loc_row=[Loc_row;t1];
    t1=t1+d;
    if(t1>I)
        flag1=1;
        break;
    end
    num1=num1+1;
end
if flag1==0
    Loc_row=[Loc_row;I];
else
    leng=length(Loc_row);
    Loc_row(leng)=I;
end

while(t2<J)
    Loc_col=[Loc_col;t2];
    t2=t2+d;
    if(t2>J)
        flag2=1;
        break;
    end
    num2=num2+1;
end
if flag2==0
    Loc_col=[Loc_col;J];
else
    leng=length(Loc_col);
    Loc_col(leng)=J;
end

while(t3<K)
    Loc_fib=[Loc_fib;t3];
    t3=t3+d;
    if(t3>K)
        flag3=1;
        break;
    end
    num3=num3+1;
end
if flag3==0
    Loc_fib=[Loc_fib;K];
else
    leng=length(Loc_fib);
    Loc_fib(leng)=K;
end

