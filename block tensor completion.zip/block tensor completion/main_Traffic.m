clear;clc;
data=load('Traffic.mat');
data=data.tensor;  
[I,J,K]=size(data);
Tensor=data;
Max_value=max(max(max(Tensor)));
Min_Value=min(min(min(Tensor)));
Tensor = (Tensor-Min_Value) ./ (Max_value-Min_Value);
R=6;
Repeat=20;
D=18;
Sample_ratio=zeros(Repeat,D-1);
Error=zeros(Repeat,D-1);
Error2=zeros(Repeat,D-1);
Time_Samp=zeros(Repeat,D-1);
Time_Recover=zeros(Repeat,D-1);
m=0;
for repeat=1 : 1 : Repeat
    m=m+1;
    n=0;
    for d= 2 : 1 : D
        n=n+1;
        max_iter=300;
        max_sub_iter=3;
        tic;
        [ID,JD,KD]=tensor_block_divide(I,J,K,d);  % 
        [IDX_C,dictionary]=tensor_block_sample(I,J,K,ID,JD,KD); 
        time_sample=toc;
        tic;
        [P_C]=tensor_block_completion(Tensor,IDX_C,dictionary,max_iter,max_sub_iter,R); 
        time_recover=toc;
        [P_T]=cp_als(tensor(Tensor.*IDX_C),R);
        P_T=double(P_T);
        
        P_T=P_T*(Max_value-Min_Value)+Min_Value;
        P_C=P_C*(Max_value-Min_Value)+Min_Value;
        UIDX_C=ones(size(IDX_C))-IDX_C;
        Error_C=sqrt( sum(sum(sum( ((P_C-data).*UIDX_C).^2 ))) / sum(sum(sum( ((data).*UIDX_C).^2  ))) );
        Error_T=sqrt( sum(sum(sum( ((P_T-data).*UIDX_C).^2 ))) / sum(sum(sum( ((data).*UIDX_C).^2  ))) );
        
        sample_ratio_C=sum(sum(sum(IDX_C))) / (I*J*K); 
        
        Time_Samp(m,n)=time_sample;
        Time_Recover(m,n)=time_recover;
        Error(m,n)=Error_C;
        Error2(m,n)=Error_T;
        Sample_ratio(m,n)=sample_ratio_C;
    end
end
